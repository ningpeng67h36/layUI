var navs = [{
	"title": "基本元素",
	"icon": "fa-cubes",
	"spread": true,
	"children": [{
		"title": "按钮",
		"icon": "",
		"href": "button.html"
	}, {
		"title": "表单",
		"icon": "",
		"href": "form.html"
	}, {
		"title": "表格",
		"icon": "",
		"href": "table.html"
	}, {
		"title": "导航",
		"icon": "",
		"href": "nav.html"
	}, {
		"title": "辅助性元素",
		"icon": "",
		"href": "auxiliar.html"
	}]
},   {
	"title": "其他",
	"icon": "fa-stop-circle",
	"href": "#",
	"spread": false,
	"children": [{
		"title": "弹窗-子窗体中打开选项卡",
		"icon": "fa-github",
		"href": "cop.html"
	}]
}];